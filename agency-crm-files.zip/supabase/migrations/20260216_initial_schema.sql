-- Enable required extension
create extension if not exists "pgcrypto";

-- Profiles mirror auth.users.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  partnership_stage text not null default 'prospecting' check (partnership_stage in ('prospecting', 'negotiating', 'onboarding', 'active', 'paused')),
  progress_percent int not null default 0 check (progress_percent >= 0 and progress_percent <= 100),
  primary_contact_name text,
  primary_contact_email text,
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner', 'admin', 'member')),
  created_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text not null,
  description text,
  status text not null default 'active' check (status in ('active', 'archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  project_id uuid references public.projects(id) on delete set null,
  title text not null,
  description text,
  status text not null default 'backlog' check (status in ('backlog', 'todo', 'in_progress', 'done', 'canceled')),
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high')),
  due_date date,
  assignee_id uuid references auth.users(id) on delete set null,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  full_name text not null,
  company text,
  email text,
  phone text,
  stage text not null default 'new' check (stage in ('new', 'qualified', 'proposal', 'negotiation', 'won', 'lost')),
  source text,
  notes text,
  next_follow_up date,
  owner_id uuid references auth.users(id) on delete set null,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.client_interactions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  client_id uuid not null references public.clients(id) on delete cascade,
  channel text not null default 'call' check (channel in ('call', 'email', 'meeting', 'whatsapp', 'other')),
  outcome text not null default 'pending' check (outcome in ('positive', 'neutral', 'negative', 'pending')),
  notes text not null,
  contacted_at timestamptz not null default now(),
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create index if not exists idx_workspace_members_user_id on public.workspace_members(user_id);
create index if not exists idx_projects_workspace_id on public.projects(workspace_id);
create index if not exists idx_tasks_workspace_id on public.tasks(workspace_id);
create index if not exists idx_tasks_project_id on public.tasks(project_id);
create index if not exists idx_tasks_status on public.tasks(status);
create index if not exists idx_clients_workspace_id on public.clients(workspace_id);
create index if not exists idx_clients_stage on public.clients(stage);
create index if not exists idx_clients_next_follow_up on public.clients(next_follow_up);
create index if not exists idx_client_interactions_workspace_id on public.client_interactions(workspace_id);
create index if not exists idx_client_interactions_client_id on public.client_interactions(client_id);
create index if not exists idx_client_interactions_contacted_at on public.client_interactions(contacted_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger set_profiles_updated_at
before update on public.profiles
for each row
execute function public.set_updated_at();

create trigger set_workspaces_updated_at
before update on public.workspaces
for each row
execute function public.set_updated_at();

create trigger set_projects_updated_at
before update on public.projects
for each row
execute function public.set_updated_at();

create trigger set_tasks_updated_at
before update on public.tasks
for each row
execute function public.set_updated_at();

create trigger set_clients_updated_at
before update on public.clients
for each row
execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    new.raw_user_meta_data ->> 'avatar_url'
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
after insert on auth.users
for each row
execute function public.handle_new_user();

create or replace function public.handle_new_workspace()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.workspace_members (workspace_id, user_id, role)
  values (new.id, new.owner_id, 'owner')
  on conflict (workspace_id, user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_workspace_created on public.workspaces;

create trigger on_workspace_created
after insert on public.workspaces
for each row
execute function public.handle_new_workspace();

create or replace function public.is_workspace_member(workspace_uuid uuid, user_uuid uuid)
returns boolean
language sql
stable
as $$
  select exists(
    select 1
    from public.workspace_members wm
    where wm.workspace_id = workspace_uuid
      and wm.user_id = user_uuid
  );
$$;

alter table public.profiles enable row level security;
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.projects enable row level security;
alter table public.tasks enable row level security;
alter table public.clients enable row level security;
alter table public.client_interactions enable row level security;

create policy "Profiles are viewable by authenticated users"
on public.profiles
for select
to authenticated
using (true);

create policy "Users can update own profile"
on public.profiles
for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

create policy "Workspace members can read workspaces"
on public.workspaces
for select
to authenticated
using (public.is_workspace_member(id, auth.uid()));

create policy "Authenticated users can create workspaces"
on public.workspaces
for insert
to authenticated
with check (auth.uid() = owner_id);

create policy "Owners and admins can update workspace"
on public.workspaces
for update
to authenticated
using (
  exists (
    select 1
    from public.workspace_members wm
    where wm.workspace_id = id
      and wm.user_id = auth.uid()
      and wm.role in ('owner', 'admin')
  )
)
with check (
  exists (
    select 1
    from public.workspace_members wm
    where wm.workspace_id = id
      and wm.user_id = auth.uid()
      and wm.role in ('owner', 'admin')
  )
);

create policy "Members can read membership"
on public.workspace_members
for select
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Owners and admins manage members"
on public.workspace_members
for all
to authenticated
using (
  exists (
    select 1
    from public.workspace_members wm
    where wm.workspace_id = workspace_members.workspace_id
      and wm.user_id = auth.uid()
      and wm.role in ('owner', 'admin')
  )
)
with check (
  exists (
    select 1
    from public.workspace_members wm
    where wm.workspace_id = workspace_members.workspace_id
      and wm.user_id = auth.uid()
      and wm.role in ('owner', 'admin')
  )
);

create policy "Members can read projects"
on public.projects
for select
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can create projects"
on public.projects
for insert
to authenticated
with check (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can update projects"
on public.projects
for update
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()))
with check (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can read tasks"
on public.tasks
for select
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can create tasks"
on public.tasks
for insert
to authenticated
with check (
  public.is_workspace_member(workspace_id, auth.uid())
  and auth.uid() = created_by
);

create policy "Members can update tasks"
on public.tasks
for update
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()))
with check (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can delete tasks"
on public.tasks
for delete
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can read clients"
on public.clients
for select
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can create clients"
on public.clients
for insert
to authenticated
with check (
  public.is_workspace_member(workspace_id, auth.uid())
  and auth.uid() = created_by
);

create policy "Members can update clients"
on public.clients
for update
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()))
with check (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can read client interactions"
on public.client_interactions
for select
to authenticated
using (public.is_workspace_member(workspace_id, auth.uid()));

create policy "Members can create client interactions"
on public.client_interactions
for insert
to authenticated
with check (
  public.is_workspace_member(workspace_id, auth.uid())
  and auth.uid() = created_by
);
