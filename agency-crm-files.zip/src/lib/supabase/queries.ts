import { cache } from 'react';

import { createClient } from './server';

export const getCurrentUser = cache(async () => {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  return user;
});

export const getDashboardData = cache(async () => {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    return { workspaces: [], tasks: [], clients: [] };
  }

  const { data: memberships } = await supabase
    .from('workspace_members')
    .select('workspace_id, workspaces(id,name,slug,partnership_stage,progress_percent,created_at)')
    .eq('user_id', user.id);

  const workspaceIds =
    memberships
      ?.map((membership) => membership.workspace_id)
      .filter((id): id is string => typeof id === 'string' && id.length > 0) ?? [];

  const workspaces = memberships?.map((membership) => membership.workspaces).filter(Boolean) ?? [];

  if (!workspaceIds.length) {
    return {
      workspaces,
      tasks: [],
      clients: []
    };
  }

  const [tasksRes, clientsRes] = await Promise.all([
    supabase
      .from('tasks')
      .select('id,title,status,priority,due_date,workspace_id,workspaces(name)')
      .in('workspace_id', workspaceIds)
      .order('updated_at', { ascending: false })
      .limit(20),
    supabase
      .from('clients')
      .select('id,full_name,stage,next_follow_up,workspace_id,workspaces(name)')
      .in('workspace_id', workspaceIds)
      .order('updated_at', { ascending: false })
      .limit(30)
  ]);

  return {
    workspaces,
    tasks: tasksRes.data ?? [],
    clients: clientsRes.data ?? []
  };
});

export async function getWorkspaceDetail(workspaceId: string) {
  const supabase = await createClient();

  const { data: workspace } = await supabase
    .from('workspaces')
    .select('id,name,slug,partnership_stage,progress_percent,primary_contact_name,primary_contact_email,created_at,owner_id')
    .eq('id', workspaceId)
    .single();

  if (!workspace) {
    return null;
  }

  const [projectsRes, tasksRes, clientsRes, interactionsRes] = await Promise.all([
    supabase
      .from('projects')
      .select('id,name,description,status,created_at')
      .eq('workspace_id', workspaceId)
      .order('created_at', { ascending: false }),
    supabase
      .from('tasks')
      .select('id,title,description,status,priority,due_date,project_id,created_at')
      .eq('workspace_id', workspaceId)
      .order('created_at', { ascending: false }),
    supabase
      .from('clients')
      .select('id,full_name,company,email,phone,stage,source,notes,next_follow_up,created_at')
      .eq('workspace_id', workspaceId)
      .order('updated_at', { ascending: false }),
    supabase
      .from('client_interactions')
      .select('id,client_id,channel,outcome,notes,contacted_at,clients(full_name)')
      .eq('workspace_id', workspaceId)
      .order('contacted_at', { ascending: false })
      .limit(15)
  ]);

  return {
    workspace,
    projects: projectsRes.data ?? [],
    tasks: tasksRes.data ?? [],
    clients: clientsRes.data ?? [],
    interactions: interactionsRes.data ?? []
  };
}
