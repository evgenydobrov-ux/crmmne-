export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string | null;
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name?: string | null;
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          full_name?: string | null;
          avatar_url?: string | null;
          updated_at?: string;
        };
      };
      workspaces: {
        Row: {
          id: string;
          name: string;
          slug: string;
          partnership_stage: 'prospecting' | 'negotiating' | 'onboarding' | 'active' | 'paused';
          progress_percent: number;
          primary_contact_name: string | null;
          primary_contact_email: string | null;
          owner_id: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          slug: string;
          partnership_stage?: 'prospecting' | 'negotiating' | 'onboarding' | 'active' | 'paused';
          progress_percent?: number;
          primary_contact_name?: string | null;
          primary_contact_email?: string | null;
          owner_id: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          name?: string;
          slug?: string;
          partnership_stage?: 'prospecting' | 'negotiating' | 'onboarding' | 'active' | 'paused';
          progress_percent?: number;
          primary_contact_name?: string | null;
          primary_contact_email?: string | null;
          updated_at?: string;
        };
      };
      workspace_members: {
        Row: {
          workspace_id: string;
          user_id: string;
          role: 'owner' | 'admin' | 'member';
          created_at: string;
        };
        Insert: {
          workspace_id: string;
          user_id: string;
          role?: 'owner' | 'admin' | 'member';
          created_at?: string;
        };
        Update: {
          role?: 'owner' | 'admin' | 'member';
        };
      };
      projects: {
        Row: {
          id: string;
          workspace_id: string;
          name: string;
          description: string | null;
          status: 'active' | 'archived';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          workspace_id: string;
          name: string;
          description?: string | null;
          status?: 'active' | 'archived';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          name?: string;
          description?: string | null;
          status?: 'active' | 'archived';
          updated_at?: string;
        };
      };
      tasks: {
        Row: {
          id: string;
          workspace_id: string;
          project_id: string | null;
          title: string;
          description: string | null;
          status: 'backlog' | 'todo' | 'in_progress' | 'done' | 'canceled';
          priority: 'low' | 'medium' | 'high';
          due_date: string | null;
          assignee_id: string | null;
          created_by: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          workspace_id: string;
          project_id?: string | null;
          title: string;
          description?: string | null;
          status?: 'backlog' | 'todo' | 'in_progress' | 'done' | 'canceled';
          priority?: 'low' | 'medium' | 'high';
          due_date?: string | null;
          assignee_id?: string | null;
          created_by: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          title?: string;
          description?: string | null;
          status?: 'backlog' | 'todo' | 'in_progress' | 'done' | 'canceled';
          priority?: 'low' | 'medium' | 'high';
          due_date?: string | null;
          assignee_id?: string | null;
          updated_at?: string;
        };
      };
      clients: {
        Row: {
          id: string;
          workspace_id: string;
          full_name: string;
          company: string | null;
          email: string | null;
          phone: string | null;
          stage: 'new' | 'qualified' | 'proposal' | 'negotiation' | 'won' | 'lost';
          source: string | null;
          notes: string | null;
          next_follow_up: string | null;
          owner_id: string | null;
          created_by: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          workspace_id: string;
          full_name: string;
          company?: string | null;
          email?: string | null;
          phone?: string | null;
          stage?: 'new' | 'qualified' | 'proposal' | 'negotiation' | 'won' | 'lost';
          source?: string | null;
          notes?: string | null;
          next_follow_up?: string | null;
          owner_id?: string | null;
          created_by: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          full_name?: string;
          company?: string | null;
          email?: string | null;
          phone?: string | null;
          stage?: 'new' | 'qualified' | 'proposal' | 'negotiation' | 'won' | 'lost';
          source?: string | null;
          notes?: string | null;
          next_follow_up?: string | null;
          owner_id?: string | null;
          updated_at?: string;
        };
      };
      client_interactions: {
        Row: {
          id: string;
          workspace_id: string;
          client_id: string;
          channel: 'call' | 'email' | 'meeting' | 'whatsapp' | 'other';
          outcome: 'positive' | 'neutral' | 'negative' | 'pending';
          notes: string;
          contacted_at: string;
          created_by: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          workspace_id: string;
          client_id: string;
          channel?: 'call' | 'email' | 'meeting' | 'whatsapp' | 'other';
          outcome?: 'positive' | 'neutral' | 'negative' | 'pending';
          notes: string;
          contacted_at?: string;
          created_by: string;
          created_at?: string;
        };
        Update: {
          channel?: 'call' | 'email' | 'meeting' | 'whatsapp' | 'other';
          outcome?: 'positive' | 'neutral' | 'negative' | 'pending';
          notes?: string;
          contacted_at?: string;
        };
      };
    };
    Views: Record<string, never>;
    Functions: {
      is_workspace_member: {
        Args: {
          workspace_uuid: string;
          user_uuid: string;
        };
        Returns: boolean;
      };
    };
    Enums: Record<string, never>;
  };
}
