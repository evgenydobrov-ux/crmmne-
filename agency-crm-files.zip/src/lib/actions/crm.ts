'use server';

import { revalidatePath } from 'next/cache';

import { z } from 'zod';

import { createClient } from '@/lib/supabase/server';

const createClientSchema = z.object({
  workspaceId: z.string().uuid(),
  fullName: z.string().min(2).max(120),
  company: z.string().max(120).optional(),
  email: z.string().email().max(160).optional(),
  phone: z.string().max(40).optional(),
  source: z.string().max(100).optional(),
  notes: z.string().max(700).optional(),
  nextFollowUp: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/u, 'Follow-up date must be YYYY-MM-DD')
    .optional(),
  stage: z.enum(['new', 'qualified', 'proposal', 'negotiation', 'won', 'lost']).default('new')
});

const updateClientStageSchema = z.object({
  workspaceId: z.string().uuid(),
  clientId: z.string().uuid(),
  stage: z.enum(['new', 'qualified', 'proposal', 'negotiation', 'won', 'lost']),
  nextFollowUp: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/u, 'Follow-up date must be YYYY-MM-DD')
    .optional()
});

const updateAgencyProgressSchema = z.object({
  workspaceId: z.string().uuid(),
  partnershipStage: z.enum(['prospecting', 'negotiating', 'onboarding', 'active', 'paused']),
  progressPercent: z.coerce.number().int().min(0).max(100),
  primaryContactName: z.string().max(120).optional(),
  primaryContactEmail: z.string().email().max(160).optional()
});

const createInteractionSchema = z.object({
  workspaceId: z.string().uuid(),
  clientId: z.string().uuid(),
  channel: z.enum(['call', 'email', 'meeting', 'whatsapp', 'other']),
  outcome: z.enum(['positive', 'neutral', 'negative', 'pending']),
  notes: z.string().min(3).max(1000),
  contactedAt: z.string().optional(),
  nextFollowUp: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/u, 'Follow-up date must be YYYY-MM-DD')
    .optional()
});

export async function createClientLead(formData: FormData) {
  const parsed = createClientSchema.safeParse({
    workspaceId: formData.get('workspaceId'),
    fullName: formData.get('fullName'),
    company: formData.get('company') || undefined,
    email: formData.get('email') || undefined,
    phone: formData.get('phone') || undefined,
    source: formData.get('source') || undefined,
    notes: formData.get('notes') || undefined,
    nextFollowUp: formData.get('nextFollowUp') || undefined,
    stage: formData.get('stage') || 'new'
  });

  if (!parsed.success) {
    return { error: 'Invalid client details. Check the required fields and email format.' };
  }

  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    return { error: 'Please log in again.' };
  }

  const { error } = await supabase.from('clients').insert({
    workspace_id: parsed.data.workspaceId,
    full_name: parsed.data.fullName,
    company: parsed.data.company ?? null,
    email: parsed.data.email ?? null,
    phone: parsed.data.phone ?? null,
    source: parsed.data.source ?? null,
    notes: parsed.data.notes ?? null,
    next_follow_up: parsed.data.nextFollowUp ?? null,
    stage: parsed.data.stage,
    created_by: user.id,
    owner_id: user.id
  });

  if (error) {
    return { error: error.message };
  }

  revalidatePath(`/workspaces/${parsed.data.workspaceId}`);
  revalidatePath('/dashboard');
  return { error: null };
}

export async function updateClientStage(formData: FormData) {
  const parsed = updateClientStageSchema.safeParse({
    workspaceId: formData.get('workspaceId'),
    clientId: formData.get('clientId'),
    stage: formData.get('stage'),
    nextFollowUp: formData.get('nextFollowUp') || undefined
  });

  if (!parsed.success) {
    return { error: 'Invalid client stage update.' };
  }

  const supabase = await createClient();

  const { error } = await supabase
    .from('clients')
    .update({
      stage: parsed.data.stage,
      next_follow_up: parsed.data.nextFollowUp ?? null
    })
    .eq('id', parsed.data.clientId)
    .eq('workspace_id', parsed.data.workspaceId);

  if (error) {
    return { error: error.message };
  }

  revalidatePath(`/workspaces/${parsed.data.workspaceId}`);
  revalidatePath('/dashboard');
  return { error: null };
}

export async function updateAgencyProgress(formData: FormData) {
  const parsed = updateAgencyProgressSchema.safeParse({
    workspaceId: formData.get('workspaceId'),
    partnershipStage: formData.get('partnershipStage'),
    progressPercent: formData.get('progressPercent'),
    primaryContactName: formData.get('primaryContactName') || undefined,
    primaryContactEmail: formData.get('primaryContactEmail') || undefined
  });

  if (!parsed.success) {
    return { error: 'Invalid agency progress values.' };
  }

  const supabase = await createClient();

  const { error } = await supabase
    .from('workspaces')
    .update({
      partnership_stage: parsed.data.partnershipStage,
      progress_percent: parsed.data.progressPercent,
      primary_contact_name: parsed.data.primaryContactName ?? null,
      primary_contact_email: parsed.data.primaryContactEmail ?? null
    })
    .eq('id', parsed.data.workspaceId);

  if (error) {
    return { error: error.message };
  }

  revalidatePath(`/workspaces/${parsed.data.workspaceId}`);
  revalidatePath('/dashboard');
  return { error: null };
}

export async function logClientInteraction(formData: FormData) {
  const parsed = createInteractionSchema.safeParse({
    workspaceId: formData.get('workspaceId'),
    clientId: formData.get('clientId'),
    channel: formData.get('channel') || 'call',
    outcome: formData.get('outcome') || 'pending',
    notes: formData.get('notes'),
    contactedAt: formData.get('contactedAt') || undefined,
    nextFollowUp: formData.get('nextFollowUp') || undefined
  });

  if (!parsed.success) {
    return { error: 'Invalid interaction details. Notes and client are required.' };
  }

  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    return { error: 'Please log in again.' };
  }

  const { error } = await supabase.from('client_interactions').insert({
    workspace_id: parsed.data.workspaceId,
    client_id: parsed.data.clientId,
    channel: parsed.data.channel,
    outcome: parsed.data.outcome,
    notes: parsed.data.notes,
    contacted_at: parsed.data.contactedAt ? new Date(parsed.data.contactedAt).toISOString() : new Date().toISOString(),
    created_by: user.id
  });

  if (error) {
    return { error: error.message };
  }

  if (parsed.data.nextFollowUp) {
    await supabase
      .from('clients')
      .update({ next_follow_up: parsed.data.nextFollowUp })
      .eq('id', parsed.data.clientId)
      .eq('workspace_id', parsed.data.workspaceId);
  }

  revalidatePath(`/workspaces/${parsed.data.workspaceId}`);
  revalidatePath('/dashboard');
  return { error: null };
}
