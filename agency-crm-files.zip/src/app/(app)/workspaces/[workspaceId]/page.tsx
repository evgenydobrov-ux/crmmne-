import { notFound } from 'next/navigation';

import { AgencyProgressForm } from '@/components/layout/agency-progress-form';
import { AnimatedSection } from '@/components/layout/animated-section';
import { ClientPipeline } from '@/components/layout/client-pipeline';
import { CreateClientForm } from '@/components/layout/create-client-form';
import { CreateProjectForm } from '@/components/layout/create-project-form';
import { CreateTaskForm } from '@/components/layout/create-task-form';
import { LogInteractionForm } from '@/components/layout/log-interaction-form';
import { RecentInteractions } from '@/components/layout/recent-interactions';
import { TaskBoard } from '@/components/layout/task-board';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { getWorkspaceDetail } from '@/lib/supabase/queries';

export default async function WorkspacePage({ params }: { params: Promise<{ workspaceId: string }> }) {
  const { workspaceId } = await params;
  const data = await getWorkspaceDetail(workspaceId);

  if (!data) {
    notFound();
  }

  return (
    <div className="space-y-6 pb-8">
      <AnimatedSection>
        <Card className="border-border/80 p-6">
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="font-display text-3xl font-semibold tracking-tight">{data.workspace.name}</h1>
            <Badge>{data.workspace.partnership_stage}</Badge>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            Slug: /{data.workspace.slug} • Agency progress: {data.workspace.progress_percent}%
          </p>
          <div className="mt-5">
            <AgencyProgressForm
              workspaceId={workspaceId}
              partnershipStage={data.workspace.partnership_stage}
              progressPercent={data.workspace.progress_percent}
              primaryContactName={data.workspace.primary_contact_name}
              primaryContactEmail={data.workspace.primary_contact_email}
            />
          </div>
        </Card>
      </AnimatedSection>

      <div className="grid gap-4 lg:grid-cols-2">
        <AnimatedSection delay={0.05}>
          <Card className="border-border/80 p-6">
            <h2 className="mb-4 font-display text-xl font-semibold">Create project</h2>
            <CreateProjectForm workspaceId={workspaceId} />

            <div className="mt-6 space-y-2">
              {data.projects.length ? (
                data.projects.map((project) => (
                  <div key={project.id} className="rounded-xl border border-border bg-background/60 p-3">
                    <p className="font-medium">{project.name}</p>
                    <p className="text-sm text-muted-foreground">{project.description || 'No description'}</p>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No projects yet.</p>
              )}
            </div>
          </Card>
        </AnimatedSection>

        <AnimatedSection delay={0.1}>
          <Card className="border-border/80 p-6">
            <h2 className="mb-4 font-display text-xl font-semibold">Create task</h2>
            <CreateTaskForm workspaceId={workspaceId} projects={data.projects} />
          </Card>
        </AnimatedSection>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <AnimatedSection delay={0.12}>
          <Card className="border-border/80 p-6">
            <h2 className="mb-4 font-display text-xl font-semibold">Add client</h2>
            <CreateClientForm workspaceId={workspaceId} />
          </Card>
        </AnimatedSection>

        <AnimatedSection delay={0.14}>
          <Card className="border-border/80 p-6">
            <h2 className="mb-4 font-display text-xl font-semibold">Log interaction</h2>
            <LogInteractionForm
              workspaceId={workspaceId}
              clients={data.clients.map((client) => ({ id: client.id, full_name: client.full_name }))}
            />
          </Card>
        </AnimatedSection>
      </div>

      <AnimatedSection delay={0.16}>
        <Card className="border-border/80 p-4 sm:p-6">
          <h2 className="mb-4 font-display text-xl font-semibold">Client pipeline</h2>
          <ClientPipeline workspaceId={workspaceId} clients={data.clients} />
        </Card>
      </AnimatedSection>

      <AnimatedSection delay={0.18}>
        <Card className="border-border/80 p-4 sm:p-6">
          <h2 className="mb-4 font-display text-xl font-semibold">Recent interactions</h2>
          <RecentInteractions interactions={data.interactions} />
        </Card>
      </AnimatedSection>

      <AnimatedSection delay={0.2}>
        <Card className="border-border/80 p-4 sm:p-6">
          <h2 className="mb-4 font-display text-xl font-semibold">Task board</h2>
          <TaskBoard workspaceId={workspaceId} tasks={data.tasks} />
        </Card>
      </AnimatedSection>
    </div>
  );
}
