import { CheckSquare, Handshake, LayoutDashboard } from 'lucide-react';

import { AnimatedSection } from '@/components/layout/animated-section';
import { CreateWorkspaceForm } from '@/components/layout/create-workspace-form';
import { RecentClients } from '@/components/layout/recent-clients';
import { RecentTasks } from '@/components/layout/recent-tasks';
import { StatCard } from '@/components/layout/stat-card';
import { WorkspaceList } from '@/components/layout/workspace-list';
import { Card } from '@/components/ui/card';
import { getDashboardData } from '@/lib/supabase/queries';

export default async function DashboardPage() {
  const { workspaces, tasks, clients } = await getDashboardData();
  const followUpsDue = clients.filter((client) => {
    if (!client.next_follow_up) {
      return false;
    }

    const dueDate = new Date(client.next_follow_up);
    const now = new Date();
    return dueDate.getTime() <= now.getTime();
  }).length;

  return (
    <div className="space-y-6 pb-8">
      <AnimatedSection>
        <Card className="border-border/80 p-6">
          <h1 className="font-display text-3xl font-semibold tracking-tight">Dashboard</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Manage partner agencies, monitor delivery progress, and track client follow-ups in one place.
          </p>
          <div className="mt-5">
            <CreateWorkspaceForm />
          </div>
        </Card>
      </AnimatedSection>

      <AnimatedSection delay={0.05}>
        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard label="Workspaces" value={workspaces.length} icon={<LayoutDashboard className="h-5 w-5" />} />
          <StatCard
            label="Open Tasks"
            value={tasks.filter((task) => task.status !== 'done' && task.status !== 'canceled').length}
            icon={<CheckSquare className="h-5 w-5" />}
          />
          <StatCard label="Follow-ups Due" value={followUpsDue} icon={<Handshake className="h-5 w-5" />} />
        </div>
      </AnimatedSection>

      <AnimatedSection delay={0.08}>
        <Card className="border-border/80">
          <h2 className="mb-4 font-display text-xl font-semibold">Your workspaces</h2>
          <WorkspaceList workspaces={workspaces} />
        </Card>
      </AnimatedSection>

      <AnimatedSection delay={0.12}>
        <Card className="border-border/80">
          <h2 className="mb-4 font-display text-xl font-semibold">Recent tasks</h2>
          <RecentTasks tasks={tasks} />
        </Card>
      </AnimatedSection>

      <AnimatedSection delay={0.16}>
        <Card className="border-border/80">
          <h2 className="mb-4 font-display text-xl font-semibold">Recent clients</h2>
          <RecentClients clients={clients} />
        </Card>
      </AnimatedSection>
    </div>
  );
}
