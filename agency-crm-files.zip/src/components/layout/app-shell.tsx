import type { ReactNode } from 'react';

import { Home, LogOut, PlusSquare } from 'lucide-react';
import Link from 'next/link';

import { logout } from '@/lib/actions/auth';

import { Logo } from './logo';
import { ThemeToggle } from './theme-toggle';
import { Button } from '../ui/button';

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-7xl flex-col px-4 py-4 sm:px-6 lg:px-8">
      <header className="mb-4 flex items-center justify-between rounded-2xl border border-border/80 bg-card/95 px-4 py-3 backdrop-blur">
        <Logo />
        <div className="flex items-center gap-2">
          <Link href="/dashboard">
            <Button variant="ghost" className="gap-2">
              <Home className="h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <Link href="/dashboard#create-workspace">
            <Button variant="ghost" className="gap-2">
              <PlusSquare className="h-4 w-4" />
              Agency
            </Button>
          </Link>
          <ThemeToggle />
          <form action={logout}>
            <Button variant="secondary" className="gap-2">
              <LogOut className="h-4 w-4" />
              Log out
            </Button>
          </form>
        </div>
      </header>
      <main className="flex-1">{children}</main>
    </div>
  );
}
