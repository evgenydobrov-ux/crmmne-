'use client';

import { useState, useTransition } from 'react';

import { Loader2, PlusCircle } from 'lucide-react';
import { useRouter } from 'next/navigation';

import { createWorkspace } from '@/lib/actions/workspaces';

import { Button } from '../ui/button';
import { Input } from '../ui/input';

export function CreateWorkspaceForm() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  return (
    <form
      id="create-workspace"
      className="flex flex-col gap-3 sm:flex-row"
      action={(formData) => {
        setError(null);
        startTransition(async () => {
          const result = await createWorkspace(formData);
          if (result?.error) {
            setError(result.error);
            return;
          }
          const form = document.getElementById('create-workspace') as HTMLFormElement | null;
          form?.reset();
          router.refresh();
        });
      }}
    >
      <Input name="name" required minLength={2} maxLength={80} placeholder="New agency workspace name" />
      <Button type="submit" className="gap-2" disabled={isPending}>
        {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <PlusCircle className="h-4 w-4" />}
        Add agency
      </Button>
      {error ? <p className="text-sm text-rose-500">{error}</p> : null}
    </form>
  );
}
