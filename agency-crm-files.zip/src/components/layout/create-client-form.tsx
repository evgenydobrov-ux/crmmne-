'use client';

import { useState, useTransition } from 'react';

import { Loader2, UserPlus } from 'lucide-react';
import { useRouter } from 'next/navigation';

import { createClientLead } from '@/lib/actions/crm';

import { Button } from '../ui/button';
import { Input } from '../ui/input';

export function CreateClientForm({ workspaceId }: { workspaceId: string }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  return (
    <form
      id="create-client"
      className="grid gap-3"
      action={(formData) => {
        setError(null);
        formData.set('workspaceId', workspaceId);

        startTransition(async () => {
          const result = await createClientLead(formData);
          if (result?.error) {
            setError(result.error);
            return;
          }
          const form = document.getElementById('create-client') as HTMLFormElement | null;
          form?.reset();
          router.refresh();
        });
      }}
    >
      <Input name="fullName" placeholder="Client full name" minLength={2} maxLength={120} required />

      <div className="grid gap-3 sm:grid-cols-2">
        <Input name="company" placeholder="Company / agency" maxLength={120} />
        <Input name="source" placeholder="Source (referral, website...)" maxLength={100} />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Input name="email" type="email" placeholder="Email" maxLength={160} />
        <Input name="phone" placeholder="Phone" maxLength={40} />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <select
          name="stage"
          defaultValue="new"
          className="h-11 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
        >
          <option value="new">New</option>
          <option value="qualified">Qualified</option>
          <option value="proposal">Proposal</option>
          <option value="negotiation">Negotiation</option>
          <option value="won">Won</option>
          <option value="lost">Lost</option>
        </select>
        <Input name="nextFollowUp" type="date" />
      </div>

      <Input name="notes" maxLength={700} placeholder="Quick notes (optional)" />

      <Button className="w-fit gap-2" type="submit" disabled={isPending}>
        {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
        Add client
      </Button>
      {error ? <p className="text-sm text-rose-500">{error}</p> : null}
    </form>
  );
}
