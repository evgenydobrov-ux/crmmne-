'use client';

import { useState, useTransition } from 'react';

import { format } from 'date-fns';
import { Loader2, Save } from 'lucide-react';
import { useRouter } from 'next/navigation';

import { updateClientStage } from '@/lib/actions/crm';

import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { EmptyState } from '../ui/empty-state';

type Client = {
  id: string;
  full_name: string;
  company: string | null;
  email: string | null;
  phone: string | null;
  stage: 'new' | 'qualified' | 'proposal' | 'negotiation' | 'won' | 'lost';
  next_follow_up: string | null;
  notes: string | null;
};

export function ClientPipeline({ workspaceId, clients }: { workspaceId: string; clients: Client[] }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  if (!clients.length) {
    return (
      <EmptyState
        title="No clients yet"
        description="Add your first lead and start tracking outreach and follow-ups."
      />
    );
  }

  return (
    <div className="space-y-3">
      {error ? <p className="text-sm text-rose-500">{error}</p> : null}

      {clients.map((client) => (
        <Card key={client.id} className="border-border/80">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="font-medium">{client.full_name}</p>
              <p className="text-sm text-muted-foreground">{client.company ?? 'No company set'}</p>
            </div>
            <Badge>{client.stage}</Badge>
          </div>

          <p className="mt-2 text-xs text-muted-foreground">
            {client.email ?? 'No email'} {client.phone ? `• ${client.phone}` : ''}
          </p>

          {client.notes ? <p className="mt-2 text-xs text-muted-foreground">{client.notes}</p> : null}

          <form
            className="mt-3 grid gap-2 sm:grid-cols-[1fr_1fr_auto]"
            action={(formData) => {
              setError(null);
              formData.set('workspaceId', workspaceId);
              formData.set('clientId', client.id);

              startTransition(async () => {
                const result = await updateClientStage(formData);
                if (result?.error) {
                  setError(result.error);
                  return;
                }
                router.refresh();
              });
            }}
          >
            <select
              name="stage"
              defaultValue={client.stage}
              className="h-10 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
              disabled={isPending}
            >
              <option value="new">New</option>
              <option value="qualified">Qualified</option>
              <option value="proposal">Proposal</option>
              <option value="negotiation">Negotiation</option>
              <option value="won">Won</option>
              <option value="lost">Lost</option>
            </select>

            <input
              name="nextFollowUp"
              type="date"
              defaultValue={client.next_follow_up ?? ''}
              className="h-10 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
              disabled={isPending}
            />

            <Button type="submit" className="gap-2" disabled={isPending}>
              {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save
            </Button>
          </form>

          <p className="mt-2 text-xs text-muted-foreground">
            Follow-up: {client.next_follow_up ? format(new Date(client.next_follow_up), 'MMM d, yyyy') : 'not set'}
          </p>
        </Card>
      ))}
    </div>
  );
}
