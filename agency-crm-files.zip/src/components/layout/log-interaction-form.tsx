'use client';

import { useState, useTransition } from 'react';

import { Loader2, MessageSquarePlus } from 'lucide-react';
import { useRouter } from 'next/navigation';

import { logClientInteraction } from '@/lib/actions/crm';

import { Button } from '../ui/button';

type ClientOption = {
  id: string;
  full_name: string;
};

export function LogInteractionForm({ workspaceId, clients }: { workspaceId: string; clients: ClientOption[] }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  return (
    <form
      id="log-interaction"
      className="grid gap-3"
      action={(formData) => {
        setError(null);
        formData.set('workspaceId', workspaceId);

        startTransition(async () => {
          const result = await logClientInteraction(formData);
          if (result?.error) {
            setError(result.error);
            return;
          }
          const form = document.getElementById('log-interaction') as HTMLFormElement | null;
          form?.reset();
          router.refresh();
        });
      }}
    >
      <select
        name="clientId"
        required
        defaultValue=""
        className="h-11 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
      >
        <option value="" disabled>
          Select client
        </option>
        {clients.map((client) => (
          <option value={client.id} key={client.id}>
            {client.full_name}
          </option>
        ))}
      </select>

      <div className="grid gap-3 sm:grid-cols-2">
        <select
          name="channel"
          defaultValue="call"
          className="h-11 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
        >
          <option value="call">Call</option>
          <option value="email">Email</option>
          <option value="meeting">Meeting</option>
          <option value="whatsapp">WhatsApp</option>
          <option value="other">Other</option>
        </select>
        <select
          name="outcome"
          defaultValue="pending"
          className="h-11 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
        >
          <option value="positive">Positive</option>
          <option value="neutral">Neutral</option>
          <option value="negative">Negative</option>
          <option value="pending">Pending</option>
        </select>
      </div>

      <textarea
        name="notes"
        required
        minLength={3}
        maxLength={1000}
        placeholder="What happened in this interaction?"
        className="min-h-28 rounded-xl border border-border bg-background/80 px-3 py-2 text-sm outline-none focus:border-primary"
      />

      <div className="grid gap-3 sm:grid-cols-2">
        <input
          name="contactedAt"
          type="datetime-local"
          className="h-11 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
        />
        <input
          name="nextFollowUp"
          type="date"
          className="h-11 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
        />
      </div>

      <Button className="w-fit gap-2" type="submit" disabled={isPending || clients.length === 0}>
        {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquarePlus className="h-4 w-4" />}
        Log interaction
      </Button>

      {clients.length === 0 ? <p className="text-sm text-muted-foreground">Create a client first.</p> : null}
      {error ? <p className="text-sm text-rose-500">{error}</p> : null}
    </form>
  );
}
