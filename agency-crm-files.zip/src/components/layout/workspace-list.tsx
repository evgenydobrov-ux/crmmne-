import Link from 'next/link';

import { ArrowRight } from 'lucide-react';

import { EmptyState } from '@/components/ui/empty-state';

import { Badge } from '../ui/badge';
import { Card } from '../ui/card';
import { Button } from '../ui/button';

type Workspace = {
  id: string;
  name: string;
  slug: string;
  partnership_stage: 'prospecting' | 'negotiating' | 'onboarding' | 'active' | 'paused';
  progress_percent: number;
  created_at: string;
};

export function WorkspaceList({ workspaces }: { workspaces: Workspace[] }) {
  if (!workspaces.length) {
    return (
      <EmptyState
        title="No workspaces yet"
        description="Create your first workspace to start organizing projects and tasks."
      />
    );
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {workspaces.map((workspace) => (
        <Card key={workspace.id} className="border-border/80">
          <div className="flex items-center justify-between">
            <p className="font-display text-lg font-semibold">{workspace.name}</p>
            <Badge>{workspace.partnership_stage}</Badge>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            /{workspace.slug} • progress {workspace.progress_percent}%
          </p>
          <div className="mt-5">
            <Link href={`/workspaces/${workspace.id}`}>
              <Button variant="secondary" className="w-full justify-between">
                Open workspace
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </Card>
      ))}
    </div>
  );
}
