import { formatDistanceToNow } from 'date-fns';

import { Badge } from '../ui/badge';
import { Card } from '../ui/card';
import { EmptyState } from '../ui/empty-state';

type Client = {
  id: string;
  full_name: string;
  stage: 'new' | 'qualified' | 'proposal' | 'negotiation' | 'won' | 'lost';
  next_follow_up: string | null;
  workspaces: { name: string } | null;
};

export function RecentClients({ clients }: { clients: Client[] }) {
  if (!clients.length) {
    return (
      <EmptyState
        title="No clients yet"
        description="Leads and client follow-ups across agencies will show up here."
      />
    );
  }

  return (
    <div className="space-y-3">
      {clients.map((client) => (
        <Card key={client.id} className="border-border/80">
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-medium">{client.full_name}</p>
            <Badge>{client.stage}</Badge>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">
            {client.workspaces?.name ?? 'Unknown workspace'}
            {client.next_follow_up
              ? ` • follow-up ${formatDistanceToNow(new Date(client.next_follow_up), { addSuffix: true })}`
              : ' • no follow-up date'}
          </p>
        </Card>
      ))}
    </div>
  );
}
