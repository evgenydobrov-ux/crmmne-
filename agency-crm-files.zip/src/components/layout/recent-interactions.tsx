import { formatDistanceToNow } from 'date-fns';

import { Card } from '../ui/card';
import { EmptyState } from '../ui/empty-state';

type Interaction = {
  id: string;
  channel: 'call' | 'email' | 'meeting' | 'whatsapp' | 'other';
  outcome: 'positive' | 'neutral' | 'negative' | 'pending';
  notes: string;
  contacted_at: string;
  clients: { full_name: string } | null;
};

export function RecentInteractions({ interactions }: { interactions: Interaction[] }) {
  if (!interactions.length) {
    return (
      <EmptyState
        title="No interactions logged"
        description="Calls, emails, and meetings will appear here after your team records them."
      />
    );
  }

  return (
    <div className="space-y-3">
      {interactions.map((interaction) => (
        <Card key={interaction.id} className="border-border/80">
          <p className="text-sm font-medium">
            {interaction.clients?.full_name ?? 'Unknown client'} • {interaction.channel}
          </p>
          <p className="mt-2 text-sm text-muted-foreground">{interaction.notes}</p>
          <p className="mt-2 text-xs text-muted-foreground">
            {interaction.outcome} • {formatDistanceToNow(new Date(interaction.contacted_at), { addSuffix: true })}
          </p>
        </Card>
      ))}
    </div>
  );
}
