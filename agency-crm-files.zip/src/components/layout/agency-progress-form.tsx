'use client';

import { useState, useTransition } from 'react';

import { Loader2, Save } from 'lucide-react';
import { useRouter } from 'next/navigation';

import { updateAgencyProgress } from '@/lib/actions/crm';

import { Button } from '../ui/button';
import { Input } from '../ui/input';

type AgencyProgressFormProps = {
  workspaceId: string;
  partnershipStage: 'prospecting' | 'negotiating' | 'onboarding' | 'active' | 'paused';
  progressPercent: number;
  primaryContactName: string | null;
  primaryContactEmail: string | null;
};

export function AgencyProgressForm({
  workspaceId,
  partnershipStage,
  progressPercent,
  primaryContactName,
  primaryContactEmail
}: AgencyProgressFormProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  return (
    <form
      className="grid gap-3"
      action={(formData) => {
        setError(null);
        formData.set('workspaceId', workspaceId);

        startTransition(async () => {
          const result = await updateAgencyProgress(formData);
          if (result?.error) {
            setError(result.error);
            return;
          }
          router.refresh();
        });
      }}
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <select
          name="partnershipStage"
          defaultValue={partnershipStage}
          className="h-11 rounded-xl border border-border bg-background/80 px-3 text-sm outline-none focus:border-primary"
        >
          <option value="prospecting">Prospecting</option>
          <option value="negotiating">Negotiating</option>
          <option value="onboarding">Onboarding</option>
          <option value="active">Active</option>
          <option value="paused">Paused</option>
        </select>

        <Input
          name="progressPercent"
          type="number"
          min={0}
          max={100}
          defaultValue={progressPercent}
          placeholder="Progress %"
          required
        />
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Input
          name="primaryContactName"
          maxLength={120}
          defaultValue={primaryContactName ?? ''}
          placeholder="Primary contact name"
        />
        <Input
          name="primaryContactEmail"
          type="email"
          maxLength={160}
          defaultValue={primaryContactEmail ?? ''}
          placeholder="Primary contact email"
        />
      </div>

      <Button className="w-fit gap-2" type="submit" disabled={isPending}>
        {isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
        Save agency progress
      </Button>
      {error ? <p className="text-sm text-rose-500">{error}</p> : null}
    </form>
  );
}
