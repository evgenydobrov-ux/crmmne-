# Pulseboard

Production-ready full-stack app built with Next.js 15, Tailwind CSS 4, Supabase Auth + Postgres, and polished Notion/Linear-inspired UI.

## Features

- Email/password authentication
- Google OAuth login
- Protected dashboard and workspace routes
- Agency workspace management
- Agency progress tracking (stage, progress %, primary contact)
- Project management per workspace
- Task management with kanban status updates and priorities
- CRM client pipeline per workspace
- Client interaction log (calls/emails/meetings) with next follow-up dates
- Row Level Security (RLS) policies for multi-tenant data access
- Responsive UI with dark/light mode and motion
- Health endpoint (`/api/health`)
- Playwright smoke tests
- CI pipeline (lint, typecheck, build)

## Stack

- Next.js 15 (App Router, Server Actions)
- TypeScript
- Tailwind CSS 4
- Supabase (`@supabase/ssr`, `@supabase/supabase-js`)
- Framer Motion
- Next Themes

## Local Setup

1. Install Node.js 22+
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy env template:
   ```bash
   cp .env.example .env.local
   ```
4. Fill `.env.local`:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (optional for future admin tasks)
   - `NEXT_PUBLIC_SITE_URL` (optional, defaults to `http://localhost:3000`)

5. In Supabase:
   - Enable Email provider in Authentication settings.
   - Enable Google provider and set redirect URL:
     - `http://localhost:3000/auth/callback` (local)
     - `https://<your-domain>/auth/callback` (production)

6. Apply DB schema:
   - Open SQL Editor in Supabase.
   - Run `supabase/migrations/20260216_initial_schema.sql`.

7. Start app:
   ```bash
   npm run dev
   ```

## Tests

Run smoke tests (app must be running):

```bash
npm run test:e2e
```

## Deploy (Vercel)

1. Push this repo to GitHub.
2. Import project in Vercel.
3. Add environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `NEXT_PUBLIC_SITE_URL` = your production URL
4. Deploy.
5. In Supabase Auth provider settings, add production callback URL:
   - `https://<your-domain>/auth/callback`

## Database Model

- `profiles`
- `workspaces`
- `workspace_members`
- `projects`
- `tasks`
- `clients`
- `client_interactions`

RLS ensures users can only access data in workspaces they belong to.
